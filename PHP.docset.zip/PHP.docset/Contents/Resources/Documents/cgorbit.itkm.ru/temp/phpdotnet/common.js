<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /temp/phpdotnet/common.js was not found on this server.</p>
<hr>
<address>Apache/2.2.3 (Debian) PHP/5.2.0-8+etch10 Server at cgorbit.itkm.ru Port 80</address>
</body></html>
