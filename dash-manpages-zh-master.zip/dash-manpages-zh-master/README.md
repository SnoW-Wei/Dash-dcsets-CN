# dash-manpages-zh
中文 Linux manpages for Dash
